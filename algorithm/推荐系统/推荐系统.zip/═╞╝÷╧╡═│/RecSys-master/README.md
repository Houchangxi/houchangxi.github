# RecSys Readme

This repo consists the training file for building a recommender system.
The IPython notebook contains all the necessary code for training a recommendation system.

Requirements:
 - TensorFlow 0.12
 - Python 3

Credits to https://github.com/songgc/TF-recomm for the base code.
